package com.cisc181.eNums;

public enum eMajor {
	CHEM, PHYSICS, NURSING
}
